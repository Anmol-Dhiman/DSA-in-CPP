#include <iostream>

int main()
{
    std::cout << "dilesh chutia h ";
    return 0;
}