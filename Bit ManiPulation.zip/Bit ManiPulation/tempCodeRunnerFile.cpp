 // for (int i = 0; i < n; i++)
    // {
    //     cin >> a[i];
    // }