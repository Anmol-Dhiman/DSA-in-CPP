#include <iostream>
using namespace std;

int count_setbits(int n)
{
    // int val;
    // int sum = 0;
    // int temp;
    // for (int i = 1; i <= n; i++)
    // {
    //     temp = i;
    //     val = 0;
    //     while (temp > 0)
    //     {
    //         temp = temp & (temp - 1);
    //         val++;
    //     }
    //     sum += val;
    // }
    // return sum;
    for(int i=; i<; i++)
    {
       
    }
}

int main()
{
    int n;
    cin >> n;
    cout << count_setbits(n) << endl;
    return 0;
}